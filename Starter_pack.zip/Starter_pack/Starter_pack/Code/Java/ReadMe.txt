Instructions for client using Java


Use your favourite IDE and create maven project with root directory competition/

Instal maven:
sudo apt-get install maven

Navigate to competition/ directory and run:
mvn clean package

Then, edit Client.java file, especially method predict() to build model and send predictions.

When you are finished, enter your credentials and run program.


********* IMPORTANT ********
If it doesn't work for you, please follow the instructions to install Protocol Compiler:

https://github.com/google/protobuf

and then run:

mvn clean package





